# Twitch Names

## Description

This mod replaces the generated names of new employees with names from followers of the Development Twitch Channel.

## Game Version

Beta 12.2 
Mod should not break on greater or lower versions.

## Bugs

I hacked this together on one evening, so please make sure, you **backup** your game. Let me know, if there are issues.

## Installation

Just move the folder in your mod folder and activate the mod in the "Mods" menu.
